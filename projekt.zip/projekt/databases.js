exports.getPassword = async function(username,pool){
    var result = await pool.query(`SELECT * FROM users WHERE username='${username}'`);
    if(result.rows.length == 0)
        return "";
    return result.rows[0].password;
}

var gameTable = ["tictac"];
var gameName = ["Kółko i krzyżyk"];
var column = ["loses","remises","wins"];

exports.register = async function(username,password,pool){
    if(password.length < 4)
        return 2;
    var result = await pool.query(`SELECT * FROM users WHERE username='${username}'`);
    if(result.rows.length > 0)
        return 1;
    await pool.query(`INSERT INTO users (username,password) VALUES ('${username}','${password}')`);
    for(let i = 0; i < gameTable.length; i++)
        await pool.query(`INSERT INTO ${gameTable[i]} (username,wins,remises,loses) VALUES ('${username}',0,0,0)`);
    return 0;
}

exports.gameResult = async function(username,gameType,result,pool){
    var r = await pool.query(`SELECT * FROM users WHERE username='${username}'`);
    console.log(`UPDATE ${gameTable[gameType]} SET ${column[result]}=${column[result]}+1 WHERE username=${username}`);
    if(r.rows.length > 0)
        await pool.query(`UPDATE ${gameTable[gameType]} SET ${column[result]}=${column[result]}+1 WHERE username='${username}'`);
    else
        return 1;
    console.log("ahh");
    return 0;
}

exports.stats = async function(username,pool){
    var r = await pool.query(`SELECT * FROM users WHERE username='${username}'`);
    if(r.rows.length == 0)
        return [];
    ret = [];
    for(let i = 0; i < gameTable.length; i++){
        r = await pool.query(`SELECT * FROM ${gameTable[i]} WHERE username='${username}'`);
        ret.push([gameName[i],r.rows[0].wins,r.rows[0].remises,r.rows[0].loses]);
    }
    return ret;
}