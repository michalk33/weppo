function tictacState(host){
    state = [[0,0,0],[0,0,0],[0,0,0],host,false,0];
    return state;
}

function getState(type,host,players){
    if(type == 0)
        return tictacState(host);
    return [];
}

function applyTicTac(room,data){
    room.state[4] = room.ended;
    if(room.state[4])
        return 5;
    usr = data[0];
    x = data[3];
    y = data[2];
    if(room.state[3] != usr)
        return 3;
    if(room.state[y][x] != 0)
        return 2;
    if(usr == room.host){
        room.state[y][x] = 1;
        room.state[3] = room.players[1];
    }else{
        room.state[y][x] = 2;
        room.state[3] = room.players[0];
    }
    var check;
    for(let p = 1; p < 3; p++){
        for(let i = 0; i < 3; i++){
            check = true;
            for(let j = 0; j < 3; j++){
                if(room.state[i][j] != p){
                    check = false;
                    break;
                }
            }
            if(check){
                room.ended = true;
                room.state[5] = p;
                room.state[4] = room.ended;
                room.state[3] = room.host;
                room.results = [(2-p)*2,(p-1)*2];
                return 0;
            }
            check = true;
            for(let j = 0; j < 3; j++){
                if(room.state[j][i] != p){
                    check = false;
                    break;
                }
            }
            if(check){
                room.ended = true;
                room.state[5] = p;
                room.state[4] = room.ended;
                room.state[3] = room.host;
                room.results = [(2-p)*2,(p-1)*2];
                return 0;
            }
        }
        check = true;
        for(let i = 0; i < 3; i++){
            if(room.state[i][i] != p){
                check = false;
                break;
            }
        }
        if(check){
            room.ended = true;
            room.state[5] = p;
            room.state[4] = room.ended;
            room.state[3] = room.host;
            room.results = [(2-p)*2,(p-1)*2];
            return 0;
        }
        check = true;
        for(let i = 0; i < 3; i++){
            if(room.state[i][2-i] != p){
                check = false;
                break;
            }
        }
        if(check){
            room.ended = true;
            room.state[5] = p;
            room.state[4] = room.ended;
            room.state[3] = room.host;
            room.results = [(2-p)*2,(p-1)*2];
            return 0;
        }
    }
    check = true;
    for(let i = 0; i < 3; i++){
        for(let j = 0; j < 3; j++){
            if(room.state[i][j] == 0){
                check = false;
                break;
            }
        }
    }
    if(check){
        room.ended = true;
        room.state[5] = 3;
        room.state[4] = room.ended;
        room.state[3] = room.host;
        room.results = [1,1];
        return 0;
    }
    return 0;
}

function applyMove(room,data){
    if(room.game == 0)
        return applyTicTac(room,data);
    return 2;
}

exports.Room = class Room{
    constructor(hostId, gameType){
        this.host = hostId;
        this.game = gameType;
        this.players = [this.host];
        this.results = "";
        this.waiting = true;
        this.state = [];
        this.ended = false;
    }
    addPlayer(playerId){
        this.players.push(playerId);
    }
    initState(){
        this.state = getState(this.game,this.host,this.players);
    }
    apply(data){
        if(this.waiting)
            return 2;
        return applyMove(this,data);
    }
}

exports.REFRESH_VALID_TIME = 120;
exports.REFRESH_IN_GAME_TIME = 120;
exports.gameTypes = ["Kółko i krzyżyk"];
exports.gameNum = {"Kółko i krzyżyk": 0}
exports.gamePlayersNum = [2];
exports.gamePlayersMaxNum = [2];
exports.gameUrls = ["tictac"];
exports.stopWhenLeft = [true];
exports.ctrlNum = 0;
exports.ctrlMod = 1000000;

exports.Player = class Player{
    constructor(inGame = "none", validTime = exports.REFRESH_VALID_TIME, logged = false){
        this.game = inGame;
        this.time = validTime;
        this.logged = logged;
        this.ctrlNum = exports.ctrlNum;
        exports.ctrlNum++;
        exports.ctrlNum %= exports.ctrlMod;
    }
}
