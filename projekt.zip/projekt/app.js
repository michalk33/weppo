var http = require('http');
var socket = require('socket.io');
var express = require('express');
var app = express();
var server = http.createServer(app);
var io = socket(server);
var cookieParser = require('cookie-parser');
var pg = require('pg');

app.use(express.urlencoded({ extended: true }));
app.use(cookieParser("tojesthaslo44"));
app.use( express.static('./'));
app.set('view engine', 'ejs');
app.set('views', './views');

var utils = require('./utils.js')
var dtbs = require('./databases.js')
var rooms = new Map();
var players = new Map();
var dataPool = new pg.Pool({
    host: 'localhost',
    database: 'weppoprojekt',
    user: 'postgres',
    password: 'haslo123'
});

//login & logout

function authorize(req, res, next) {
        if ( req.signedCookies.username ) {
            (async () => {
                var pwd = await dtbs.getPassword(req.signedCookies.username,dataPool);
                if( !players.has(req.signedCookies.username) && pwd == "" ){
                    res.cookie('username', '', { maxAge: -1 } );
                    res.redirect('/login?returnUrl='+req.url);
                }else if(players.has(req.signedCookies.username) && pwd == "" && req.signedCookies.ctrlnum != players.get(req.signedCookies.username).ctrlNum){
                    res.cookie('username', '', { maxAge: -1 } );
                    res.redirect('/login?returnUrl='+req.url);
                }else{
                    if(!players.has(req.signedCookies.username)){
                        players.set(req.signedCookies.username,new utils.Player());
                        players.get(req.signedCookies.username).logged = true;
                        players.get(req.signedCookies.username).ctrlNum = req.signedCookies.ctrlNum;

                    }
                    players.get(req.signedCookies.username).time = utils.REFRESH_VALID_TIME;
                    req.username = req.signedCookies.username;
                    next();
                }
            })();
        } else {
            res.redirect('/login?returnUrl='+req.url);
        }
}

app.get( '/logout', (req, res) => {
    usr = req.signedCookies.username;
    if(players.has(usr) && !players.get(usr).logged )
        players.get(usr).time = 1;
    res.cookie('username', '', { maxAge: -1 } );
    res.redirect('/');
});

app.get( '/login', (req, res) => {
    res.render('login');
})

app.post( '/login', (req, res) => {
    var username = req.body.username;
    var password = req.body.password;
    (async () => {
        var pwd = await dtbs.getPassword(username,dataPool);
        if ( pwd == password && pwd != "" ) {
            if( !players.has(username) ){
                players.set(username,new utils.Player());
                players.get(username).logged = true;
            }
            res.cookie('username', username, { signed: true });
            res.redirect(req.query.returnUrl);
        } else {
            res.render( 'login', { message : "Niepoprawne dane logowania." });
        }
    })()
});

//register

app.get( '/register', (req, res) => {
    res.render('register');
});

app.post( '/register', (req, res) => {
    var username = req.body.username;
    var password = req.body.password;
    var rs = 3;
    (async () => {
        rs = await dtbs.register(username,password,dataPool,res);
        if(rs == 0){
            res.render('register', { message : "Rejestracja przebiegła pomyślnie!" })
        }else if(rs == 1){
            res.render('register', { message : "Nazwa użytkownika jest zajęta!" });
        }else if(rs == 2){
            res.render('register', { message : "Hasło musi mieć długość co najmniej 4 znaków." });
        }else{
            res.render('register', { message : "Rejestracja nie powiodła się!" });
        }
    })()
});

//setnick

app.get( '/setnick', (req, res) => {
    res.render('setnick');
})

app.post( '/setnick', (req, res) => {
    var username = req.body.username;
    (async () => {
        var pwd = await dtbs.getPassword(username,dataPool);
        if(pwd == "" && !players.has(username)){
            players.set(username,new utils.Player());
            res.cookie('username', username, { signed: true });
            res.cookie('ctrlnum', players.get(username).ctrlNum, { signed: true });
            res.redirect('/');
        }else{
            res.render('setnick', { message : "Nick jest zajęty." });
        }
    })()
});

//main

app.get('/', (req, res) => {
    if ( req.signedCookies.username ) {
        res.render('app', {logged: true, username: req.signedCookies.username});
    }else{
        res.render('app', {logged: false});
    }
});

//game_not_found

app.get('/game_not_found', (req, res) => {
    if ( req.signedCookies.username ) {
        res.render('app', {logged: true, msg: "Nie znaleziono pokoju.", username: req.signedCookies.username});
    }else{
        res.render('app', {logged: false, msg: "Nie znaleziono pokoju."});
    }
});

//stats

app.get('/stats', authorize, (req, res) => {
    (async ()=>{
        stats = await dtbs.stats(req.username,dataPool);
        res.render('stats', {data: stats, username: req.signedCookies.username});
    })();
});

//rooms

app.get('/rooms', authorize, (req, res) => {
    var rn = 0;
    rooms.forEach(function(v,k,m){
        if(v.waiting && v.players.length < utils.gamePlayersMaxNum[v.game])
            rn++;
    })
    res.render('rooms', {rooms: rooms, gameTypes: utils.gameTypes, roomsNum: rn.toString(), mxNum: utils.gamePlayersMaxNum, username: req.signedCookies.username});
});

app.post( '/rooms', authorize, (req, res) => {
    username = req.signedCookies.username;
    var room = players.get(username).game;
    if(room != "none")
        res.redirect('/join?room=' + room);
    else{
        var gameType = req.body.gameType;
        roomname = "room_" + username;
        gNum = utils.gameNum[gameType];
        rooms.set(roomname, new utils.Room(username, gNum));
        players.get(username).game = roomname;
        res.redirect('/' + utils.gameUrls[gNum]);
    }
});

//join

app.get('/join', authorize, (req, res) => {
    var room = players.get(req.username).game;
    if(room != "none" && rooms.has(room) && rooms.get(room).players.includes(req.username) && req.query.room != room){
        res.redirect('/join?room=' + room);
    }else{
        room = req.query.room;
        if( !rooms.has(room) ){
            res.redirect('/game_not_found');
        }else{
            game = rooms.get(room);
            if(game.players.length >= utils.gamePlayersMaxNum[game.game] || !game.waiting){
                res.redirect('/game_not_found');
            }else{
                if(!game.players.includes(req.username))
                    game.players.push(req.username);
                players.get(req.username).game = room;
                res.redirect('/' + utils.gameUrls[rooms.get(room).game]);
            }
        }
    }
});

//tictac

app.get('/tictac', authorize, (req, res) => {
    var username = req.username;
    var room = players.get(username).game;
    if( room == "none" || !rooms.get(room).players.includes(username) ){
        res.redirect('/rooms');
    }else{
        res.render('tictac', {room: room, username: username});
    }
});

//periodic control

setInterval( function() {
    players.forEach((val,key,map) => {
        if( val.time > 0 )
            val.time--;
        if( val.time <= 0 ){
            if(rooms.has(val.game)){
                game = rooms.get(val.game);
                for(let i = 0; i < game.players.length; i++){
                    if(game.players[i] == key){
                        game.players[i] = game.players[game.players.length-1];
                        game.players.length--;
                        if(utils.stopWhenLeft[game.game] && game.waiting == false)
                            game.ended = true;
                        break;
                    }
                }
            }
            val.game = "none";
            if( !val.logged ){
                players.delete(key);
            }
        }
    } )
    rooms.forEach((val,key,map) => {
        if( val.players.length == 0 && ( val.results == "" || val.waiting ) ){
            rooms.delete(key);
        }
        if(val.ended){
            if(val.game == 0)
                val.state[4] = true;
            if(val.results != ""){
                (async () => {
                    for(let i = 0; i < val.players.length; i++)
                        await dtbs.gameResult(val.players[i],val.game,val.results[i],dataPool);
                    val.results = "";
                })();
            }
        }
    } )
}, 1000 );

//socket io

io.on('connection', function(socket) {
    socket.on('start', function(data) {
        if(players.has(data[0]) && rooms.has(data[1]) && players.get(data[0]).game == data[1] && rooms.get(data[1]).players.includes(data[0])){
            socket.join(data[1]);
            if(rooms.get(data[1]).host == data[0])
                socket.emit("you are host");
            players.get(data[0]).time = utils.REFRESH_IN_GAME_TIME;
            io.to(data[1]).emit("players number", rooms.get(data[1]).players.length);
        }else{
            socket.emit("error", 1);
        }
    });
    socket.on('start game', function(data) {
        if(players.has(data[0]) && rooms.has(data[1]) && players.get(data[0]).game == data[1] && rooms.get(data[1]).players.includes(data[0]) && rooms.get(data[1]).host == data[0]){
            rm = rooms.get(data[1]);
            players.get(data[0]).time = utils.REFRESH_IN_GAME_TIME;
            if(rm.players.length >= utils.gamePlayersNum[rm.game] && rm.players.length <= utils.gamePlayersMaxNum[rm.game]){
                rm.waiting = false;
                rm.initState();
                io.to(data[1]).emit("change");
            }else{
                socket.emit("error", 4);
            }
        }else{
            socket.emit("error", 1);
        }
    });
    socket.on('refresh', function(data) {
        if(players.has(data[0]) && rooms.has(data[1]) && players.get(data[0]).game == data[1] && rooms.get(data[1]).players.includes(data[0])){
            if(!rooms.get(data[1]).waiting)
                socket.emit("state",rooms.get(data[1]).state);
            players.get(data[0]).time = utils.REFRESH_IN_GAME_TIME;
        }else{
            socket.leave(data[1]);
            socket.emit("error", 1);
        }
    });
    socket.on('move', function(data){
        if(players.has(data[0]) && rooms.has(data[1]) && players.get(data[0]).game == data[1] && rooms.get(data[1]).players.includes(data[0])){
            players.get(data[0]).time = utils.REFRESH_IN_GAME_TIME;
            res = rooms.get(data[1]).apply(data);
            if(res > 0)
                socket.emit("error", res);
            else
                io.to(data[1]).emit("change");
        }else{
            socket.emit("error", 1);
        }
    });
    socket.on('leave', function(data){
        if(players.has(data[0]) && rooms.has(data[1]) && players.get(data[0]).game == data[1] && rooms.get(data[1]).players.includes(data[0])){
            players.get(data[0]).game = "none";
            players.get(data[0]).time = utils.REFRESH_VALID_TIME;
            game = rooms.get(data[1]);
            for(let i = 0; i < game.players.length; i++){
                if(game.players[i] == data[0]){
                    game.players[i] = game.players[game.players.length-1];
                    game.players.length--;
                    if(data[0] == game.host){
                        game.waiting = false;
                        game.ended = true;
                    }
                    if(utils.stopWhenLeft[game.game] && game.waiting == false)
                        game.ended = true;
                    break;
                }
            }
            io.to(data[1]).emit("player left");
        }else{
            if(players.has(data[0])){
                players.get(data[0]).game = "none";
                players.get(data[0]).time = utils.REFRESH_VALID_TIME;
            }
            socket.emit("error", 1);
        }
    });
});


/*
Errors:
1 - wrong username or/and room name
2 - invalid movement
3 - opponent's movement
4 - too small number of players
5 - game ended
*/

server.listen(process.env.PORT || 3000);